-- Example SQL validation: verify that a transfer of 100 resulted in two ledger rows and net-zero impact
-- Replace schema/table names with your DB's tables
-- Parameters: from_account_id, to_account_id, amount, transaction_id

SELECT COUNT(*) AS ledger_rows
FROM ledger_entries
WHERE transaction_id = '<TRANSACTION_ID>';

-- Expected ledger_rows = 2 (debit + credit)

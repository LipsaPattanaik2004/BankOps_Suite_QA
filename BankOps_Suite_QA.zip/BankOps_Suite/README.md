# BankOps Suite – Flask Banking System (QA Focus)

**Overview**
BankOps Suite is a QA-focused test pack for a Flask-based banking system. It contains test scenarios, sample automated test code (PyTest + Selenium), SQL validation snippets, and documentation to help you run and extend the test suite.

**What's included**
- README.md (this file)
- DESCRIPTION.txt (short description)
- EXTENDED_DESCRIPTION.md (detailed description and testing approach)
- requirements.txt (Python packages suggested)
- tests/ (sample pytest and API test stubs)
- sql_checks/ (example SQL validation scripts)
- .gitignore

**How to use**
1. Create a Python virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate   # mac/linux
   venv\Scripts\activate    # windows
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run API tests (PyTest):
   ```bash
   pytest -q
   ```
4. For Selenium UI tests, ensure a webdriver (e.g. chromedriver) is on PATH and a test app instance is running.

**Notes**
- Replace placeholders (BASE_URL, DB connection details) in tests with your environment values.
- This package is a starting point — expand tests and CI integration per your project needs.
